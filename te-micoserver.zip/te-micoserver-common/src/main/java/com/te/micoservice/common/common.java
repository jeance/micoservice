package com.te.micoservice.common;

/**
 * Created by cxj4842 on 2018/7/8.
 */
public class common {
}
